// 1.Declare a variable called firstVar but don't initialise it with a value.

var firstVar;

// 2.Declare a variable called name and assign it your first name.

var name = "ben";
console.log(name);

// 3.Declare and initialise a variable with a number value.

var benborn = 1986;
console.log(benborn);

// 4.Create a variable called division and initialise it with a value of 20 divided by 5.

var division = 20 / 5;
//consol log answer
division;
4;

// 5.Write code that checks the type of the value "frog".
typeof "frog";
// "string"

// 6.Declare and initialise a variable called orderHasShipped with a boolean value.
orderHasShipped = true;
// 7.Create an if statement that checks if orderHasShipped is true. If it is true, console log the string value "true". If not, console log the string value "false".
var orderHasShipped = true;

if (orderHasShipped === true) {
  console.log("true");
} else {
  console.log("fail");
}

// 8.Create a for loop that counts from 0 to 9. Console log the value of the counter variable inside the loop.
for (var i = 0; i <= 9; i++) {
  console.log(i);
}
